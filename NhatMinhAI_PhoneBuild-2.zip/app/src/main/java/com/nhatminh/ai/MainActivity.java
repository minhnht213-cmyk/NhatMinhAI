package com.nhatminh.ai;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.view.Gravity;
import android.widget.*;
import android.graphics.Typeface;

public class MainActivity extends Activity {
    private static final int PICK_IMAGE=21;
    LinearLayout root;
    TextView status;
    EditText question;
    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        build();
    }
    int dp(int v){ return (int)(v*getResources().getDisplayMetrics().density); }
    TextView text(String s,int size,int color,boolean bold){
        TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if(bold)t.setTypeface(null,Typeface.BOLD); return t;
    }
    void build(){
        ScrollView scroll=new ScrollView(this); scroll.setBackgroundColor(Color.rgb(11,16,32));
        root=new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(18),dp(24),dp(18),dp(24));
        scroll.addView(root); setContentView(scroll);
        LinearLayout hero=card();
        hero.addView(text("✦ NhatMinh AI",25,Color.WHITE,true));
        hero.addView(text("Chụp bài tập • Học từng bước",14,0xffaab6d0,false));
        root.addView(hero);
        LinearLayout c=card(); c.addView(text("📷 Ảnh bài tập",18,Color.WHITE,true));
        Button pick=button("Chọn ảnh từ điện thoại");
        pick.setOnClickListener(v->{Intent i=new Intent(Intent.ACTION_GET_CONTENT);i.setType("image/*");startActivityForResult(i,PICK_IMAGE);});
        c.addView(pick);
        question=new EditText(this); question.setHint("Hoặc nhập / dán đề bài vào đây"); question.setTextColor(Color.WHITE);question.setHintTextColor(0xff9eabc5);question.setMinLines(4);question.setGravity(Gravity.TOP);question.setBackgroundColor(0xff0e1628);
        c.addView(question,new LinearLayout.LayoutParams(-1,dp(130)));
        Button submit=button("Xem hướng dẫn giải"); submit.setOnClickListener(v->{
            String q=question.getText().toString().trim();
            if(q.isEmpty()){status.setText("Chọn ảnh hoặc nhập đề bài trước nhé.");}
            else status.setText("Đề bài đã nhập. Bạn có thể gửi nội dung này vào ChatGPT để được giải thích từng bước, kiểm tra cách làm và đáp án.");
        }); c.addView(submit);
        root.addView(c);
        LinearLayout out=card();out.addView(text("Kết quả / hướng dẫn",18,Color.WHITE,true));
        status=text("Kết quả sẽ hiển thị ở đây.",15,0xffdce4ff,false);status.setPadding(dp(12),dp(12),dp(12),dp(12));status.setBackgroundColor(0xff0e1628);out.addView(status);root.addView(out);
        LinearLayout foot=card();foot.addView(text("Phiên bản mẫu • Hỗ trợ học tập • Không tự thao tác trong ứng dụng khác",12,0xff9eabc5,false));root.addView(foot);
    }
    LinearLayout card(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);l.setPadding(dp(16),dp(16),dp(16),dp(16));l.setBackgroundColor(0xff151d30);LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-1,-2);p.bottomMargin=dp(14);root.addView(l,p);return l;}
    Button button(String label){Button b=new Button(this);b.setText(label);b.setTextColor(Color.WHITE);b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(0xff647cff));return b;}
    @Override protected void onActivityResult(int req,int res,Intent data){super.onActivityResult(req,res,data);if(req==PICK_IMAGE&&res==RESULT_OK&&data!=null){Uri u=data.getData();question.setText("Đã chọn ảnh: "+u.getLastPathSegment()+"\nVui lòng nhập nội dung bài trong ảnh để được hỗ trợ.");status.setText("Đã chọn ảnh. Phiên bản mẫu hiện chưa có OCR tích hợp.");}}
}
