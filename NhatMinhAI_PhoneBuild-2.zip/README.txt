NhatMinhAI APK project

Phone-only build via GitHub Actions:
1. Create a GitHub account or sign in in your browser.
2. Create a new repository (public or private).
3. Upload the contents of this ZIP to the repository root (including .github/workflows/build.yml).
4. Open Actions tab and select "Build NhatMinh AI APK", then tap Run workflow.
5. When complete, open the workflow run and download the artifact named NhatMinhAI-debug-apk.
6. Extract the artifact ZIP to get app-debug.apk, then install it.

This starter is only a UI shell. It does not yet include OCR or AI backend.
